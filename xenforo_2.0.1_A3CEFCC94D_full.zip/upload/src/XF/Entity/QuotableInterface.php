<?php

namespace XF\Entity;

interface QuotableInterface
{
	public function getQuoteWrapper($inner);
}