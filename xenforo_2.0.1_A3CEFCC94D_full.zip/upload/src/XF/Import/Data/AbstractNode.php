<?php

namespace XF\Import\Data;

abstract class AbstractNode extends AbstractEmulatedData
{
}