<?php

namespace XF\Import\Data;

class vBulletinBlogUser extends Node
{
	public function getImportType()
	{
		return 'blog_user';
	}
}