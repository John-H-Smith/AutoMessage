<?php

namespace XF\Legacy\ControllerResponse;

class Redirect
{
	const RESOURCE_CREATED = 1;
	const RESOURCE_UPDATED = 2;
	const RESOURCE_CANONICAL = 3;
	const RESOURCE_CANONICAL_PERMANENT = 5;
	const SUCCESS = 4;
}